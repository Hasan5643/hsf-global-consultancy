# HSF Global Consultancy Website

A responsive, bilingual (English/Bangla) static website for GitHub Pages.

## Before publishing
1. Confirm the WhatsApp/phone number in `index.html` (`+8801568-285643`, link format `8801568285643`).
2. Confirm `info@hsfglobalconsultancy.com` is an active mailbox before publishing it.
3. Update any wording to match the exact services your business is authorized and able to provide.
4. The website does not promise visa approval, admission, jobs, or invitation letters.

## Publish with GitHub Pages (free)
1. Sign in or create an account at https://github.com/
2. Create a new **public** repository, for example `hsf-global-consultancy`.
3. Upload `index.html` to the repository's root folder.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch **main** and folder **/(root)**, then click **Save**.
7. Wait a few minutes. GitHub will show the published URL in the Pages section, usually:
   `https://YOUR-USERNAME.github.io/hsf-global-consultancy/`

## Edit the site
Open `index.html` in GitHub and click the pencil (Edit) icon. Make changes and commit them.
To change the phone number, search for `8801568285643` and `+880 1568-285643`.
To change the email, search for `info@hsfglobalconsultancy.com`.

## Important
GitHub Pages hosts static sites. The WhatsApp buttons work, but this template does not include a database, application submission backend, or payment processing.
